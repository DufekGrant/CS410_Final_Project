chrome.runtime.onMessage.addListener(function (request,sender,sendResponse){
    if (request.action === 'getText') {
        const text = Array.from(documentSelectorAll('p')).map(p=> p.textContent.trim());
        sendResponse(text)
    }
})