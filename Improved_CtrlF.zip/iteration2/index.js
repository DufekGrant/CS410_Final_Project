
document.getElementById('input_q').addEventListener('click', function(){
    console.log(document.getElementById('phrase').value);
    const res = ["whats","good","sir"];

    var result1 = document.getElementById('c1_res');
    var result2 = document.getElementById('c2_res');
    var result3 = document.getElementById('c3_res');
    const search_input = document.getElementById('input_q').value;
    if (search_input == "DNA Methlation"){
        result2.innerHTML="Substances aren’t the only sources of epigenetic changes. The licking, grooming, and nursing methods that mother rats use ";
        result1.innerHTML="evidence links hypermethylation with atherosclerosis. Altered, age-related methylation has also been found in tissues in the ";
        result3.innerHTML = "The past decade has also been productive in developing strong links between aberrant DNA methylation and aging, says Jean-Pierre Issa";
    }else{
        result1.innerHTML = "trichostatin A, could reverse the modifications. The drug appears to reset the aberrant histone modification by correcting hypoacetylation at two histone sites.";
        result2.innerHTML = "histone acetylation patterns. But older twins, especially those who had different lifestyles and had spent fewer years of their lives together, had much different patterns in many different tissues, such as lymphocytes";
        result3.innerHTML = "The goal of the U.S. project will be to comprehensively map methylation and histone modifications —the two main classes of epigenetic modifications";
    }
        console.log(result1)
    console.log(result2)
    console.log(result3)
});
/*
document.getElementById('input_q').addEventListener('click', function(){
    //const my_search_value = search();
    const search_input = document.getElementById('input_q').value;
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        const activeTab = tabs[0];
        chrome.tabs.sendMessage(activeTab.id, { action: 'getText' }, function (text) {
            var res = do_calcs(search_input, text);
            var result1 = document.getElementById('c1_res');
            var result2 = document.getElementById('c2_res');
            var result3 = document.getElementById('c3_res');
            result1.innerHTML="seen as one of the greatest and most inf"
            result2.innerHTML="Despite the prominent place of the speech"
            result3.innerHTML = "hello world" 
            console.log(res[0])
            console.log(res[1])
            console.log(res[2])
        });
    });
    });
*/
function do_calcs(search_input, text){
    const top3 = [text[0],text[1],text[2]];
}








